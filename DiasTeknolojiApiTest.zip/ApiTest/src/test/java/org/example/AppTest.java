package org.example;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;


public class AppTest {

    private static final String baseURI = "https://restful-booker.herokuapp.com";

    @BeforeClass
    public static void setup() {
        RestAssured.baseURI = baseURI;
        RestAssured.useRelaxedHTTPSValidation();
    }

    @Test(priority = 1)
    public void healthCheckTest() {
        Response response = given()
                .get("/ping");

        Assert.assertEquals(response.getStatusCode(), 201, "Api is down");
    }
    @Test(priority = 3)
    public void getAllBookingIdsTest() {
        given()
                .when()
                .get("/booking")
                .then()
                .statusCode(200)
                .body("size()", notNullValue());
    }

    @Test(priority = 2)
    public void authCreateTokenTest() {
        String authBody = "{\n" +
                "    \"username\" : \"admin\",\n" +
                "    \"password\" : \"password123\"\n" +
                "}";

        given()
                .contentType(ContentType.JSON)
                .body(authBody)
                .when()
                .post("/auth")
                .then()
                .statusCode(200)
                .body("token", notNullValue());
    }

    @Test(priority = 4)
    public void createBookingTest() {
        String requestBody = "{\n" +
                "    \"firstname\" : \"John\",\n" +
                "    \"lastname\" : \"Doe\",\n" +
                "    \"totalprice\" : 123,\n" +
                "    \"depositpaid\" : true,\n" +
                "    \"bookingdates\" : {\n" +
                "        \"checkin\" : \"2024-03-25\",\n" +
                "        \"checkout\" : \"2024-03-30\"\n" +
                "    },\n" +
                "    \"additionalneeds\" : \"Breakfast\"\n" +
                "}";

        given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .when()
                .post("/booking")
                .then()
                .statusCode(200)
                .body("bookingid", notNullValue());
    }

    @Test(priority = 5)
    public void getBookingByIdTest() {
        int bookingId =
                given()
                        .when()
                        .get("/booking")
                        .then()
                        .extract().jsonPath().getInt("[0].bookingid");

        given()
                .when()
                .get("/booking/" + bookingId)
                .then()
                .statusCode(200)
                .body("firstname", notNullValue());
    }



    @Test(priority = 6)
    public void updateBookingTest() {
        String authBody = "{\n" +
                "    \"username\" : \"admin\",\n" +
                "    \"password\" : \"password123\"\n" +
                "}";

        String token = given()
                .contentType(ContentType.JSON)
                .body(authBody)
                .post("/auth")
                .then().extract().path("token");

        String updateBody = "{\n" +
                "    \"firstname\" : \"Emre\",\n" +
                "    \"lastname\" : \"QA\",\n" +
                "    \"totalprice\" : 250,\n" +
                "    \"depositpaid\" : false,\n" +
                "    \"bookingdates\" : {\n" +
                "        \"checkin\" : \"2024-04-01\",\n" +
                "        \"checkout\" : \"2024-04-10\"\n" +
                "    },\n" +
                "    \"additionalneeds\" : \"Lunch\"\n" +
                "}";

        int bookingId = given()
                .contentType(ContentType.JSON)
                .body(updateBody)
                .post("/booking")
                .then().extract().path("bookingid");

        given()
                .contentType(ContentType.JSON)
                .header("Cookie", "token=" + token)
                .body(updateBody)
                .when()
                .put("/booking/" + bookingId)
                .then()
                .statusCode(200)
                .body("firstname", equalTo("Emre"));
    }

    @Test(priority = 7)
    public void deleteBookingTest() {
        String authBody = "{\n" +
                "    \"username\" : \"admin\",\n" +
                "    \"password\" : \"password123\"\n" +
                "}";

        String token = given()
                .contentType(ContentType.JSON)
                .body(authBody)
                .post("/auth")
                .then().extract().path("token");

        // İlk olarak yeni bir booking oluştur
        String bookingRequestBody = "{\n" +
                "    \"firstname\" : \"Test\",\n" +
                "    \"lastname\" : \"User\",\n" +
                "    \"totalprice\" : 123,\n" +
                "    \"depositpaid\" : true,\n" +
                "    \"bookingdates\" : {\n" +
                "        \"checkin\" : \"2024-04-01\",\n" +
                "        \"checkout\" : \"2024-04-05\"\n" +
                "    },\n" +
                "    \"additionalneeds\" : \"Lunch\"\n" +
                "}";

        int bookingId = given()
                .contentType(ContentType.JSON)
                .body(bookingRequestBody)
                .post("/booking")
                .then().extract().path("bookingid");


        given()
                .header("Cookie", "token=" + token)
                .when()
                .delete("/booking/" + bookingId)
                .then()
                .statusCode(201); // API dokümantasyonuna göre doğru durum kodu 201
    }
}