package pages;

import base.BaseTest;
import base.Driver;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class HomePage extends BaseTest {
    private WebDriver driver;

    @BeforeMethod
    @Parameters("browser")
    public void setup(String browser) {
        if (browser.equals("chrome")) {
            System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
            driver = new ChromeDriver();
        } else if (browser.equals("firefox")) {
            System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");
            driver = new FirefoxDriver();
        }

        // Tarayıcı ayarları
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }
    private String logoCheckXpath = "//a[contains(@href, 'hepsiburada.com')]/img";
    private String electronicCategoryXapth = "//span[contains(text(), 'Elektronik')]";

    String partialId = "NavigationDesktop";
    int listItemIndex = 1;
    int subListItemIndex = 1;
    private String tabletCategoryXpath = "//*[contains(@id, '" + partialId + "')]/div/div/div/div/div[1]/div/ul/li[" + listItemIndex + "]/div/div/div/div[1]/ul/li[" + subListItemIndex + "]/a";
    private String titleXpath = "//*[@id=\"page_title\"]/div[1]/h1";
    private String acceptCookiesXpath = "//*[@id=\"onetrust-accept-btn-handler\"]";
    private String brandNameXpath = "//*[@href=\"/apple-bilgisayarlar-xc-2147483646-b8849\"]";
    private String selectIncXpath = "//*[@id=\"ekranboyutu\"]/div/div/div/div/div/div[3]/div/div[10]/label/input";
    private String screenSizeXpath = "//*[@id=\"ekranboyutu\"]";



    public HomePage()
    {
        driver = Driver.getDriver();
        PageFactory.initElements(driver,this);
    }

    public void checkHomePage() {
        driver.findElement(By.xpath(logoCheckXpath));
        driver.findElement(By.xpath(acceptCookiesXpath)).click();

    }
    public void navigateToTabletCategory() throws InterruptedException {
        Thread.sleep(2000);
         Actions actions = new Actions(driver);
         actions.moveToElement(driver.findElement(By.xpath(electronicCategoryXapth))).perform();
         driver.findElement(By.xpath(tabletCategoryXpath)).click();
    }
    public void checkTabletCategoryPage() throws InterruptedException {
        Thread.sleep(2000);
        WebElement title = driver.findElement(By.xpath(titleXpath));
        String expectedText = "Bilgisayar Fiyatları ve Modelleri";
        if (title != null && title.getText().contains(expectedText)) {
            System.out.println("Metin doğrulandı: 'Bilgisayar Fiyatları ve Modelleri' metni sayfada bulundu.");
        } else {
            System.out.println("Metin doğrulanamadı: 'Bilgisayar Fiyatları ve Modelleri' metni sayfada bulunamadı.");
        }
    }

    public void searchForBrand() {
        driver.findElement(By.xpath(brandNameXpath)).click();
        driver.navigate().refresh();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.findElement(By.xpath(screenSizeXpath)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(selectIncXpath)));
        driver.findElement(By.xpath(selectIncXpath)).click();
    }

    public void clickMaxPriceProduct() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Hepsiburada sayfasına git
            driver.get("https://www.hepsiburada.com/apple-bilgisayarlar-xc-2147483646-b8849");

            // Tüm ürün fiyatlarını bul
            List<WebElement> productPrices = driver.findElements(By.xpath("//div[contains(@class, 'productListContent')]//div[contains(@data-test-id, 'price-current-price')]"));
            List<WebElement> productCards = driver.findElements(By.xpath("//div[contains(@class, 'productListContent')]//div[contains(@class, 'product-card')]"));

            double maxPrice = 0;
            WebElement maxPriceProduct = null;

            // En yüksek fiyatlı ürünü bul
            for (int i = 0; i < productPrices.size(); i++) {
                String priceText = productPrices.get(i).getText().replaceAll("[^0-9,]", "").replace(",", ".");
                double price = Double.parseDouble(priceText);

                if (price > maxPrice) {
                    maxPrice = price;
                    maxPriceProduct = productCards.get(i);
                }
            }

            if (maxPriceProduct != null) {
                // En pahalı ürünü detay sayfasına gitmek için tıkla
                maxPriceProduct.findElement(By.xpath(".//a")).click();

                // Sepete Ekle butonuna tıkla
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(), 'Sepete Ekle')]"))).click();

                System.out.println("En pahalı ürün sepete eklendi.");
            } else {
                System.out.println("Ürün bulunamadı.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Tarayıcıyı kapat
            driver.quit();
        }
    }
}



