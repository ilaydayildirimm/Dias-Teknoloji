package stepdefs;

import base.Driver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pages.HomePage;


import java.time.Duration;

public class MyStepdefs {

    HomePage homePage = new HomePage();
    private WebDriver driver;
    @Given("User navigates to home page")
    public void userNavigatesToHomePage() {
        driver = Driver.getDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hepsiburada.com/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    }

    @Then("User should see the home page")
    public void userShouldSeeTheHomePage() {
        homePage.checkHomePage();
    }

    @And("User navigate to tablet category")
    public void userNavigateToTabletCategory() throws InterruptedException {
        homePage.navigateToTabletCategory();
    }

    @Then("User should see the tablet category page")
    public void userShouldSeeTheTabletCategoryPage() throws InterruptedException {
        homePage.checkTabletCategoryPage();
    }

    @And("User search for brand name for Apple")
    public void userSearchForOnTheSearchBar() {
        homePage.searchForBrand();
    }

    @And("User click max price product")
    public void userClickMaxPriceProduct() {
        homePage.clickMaxPriceProduct();
    }
}

